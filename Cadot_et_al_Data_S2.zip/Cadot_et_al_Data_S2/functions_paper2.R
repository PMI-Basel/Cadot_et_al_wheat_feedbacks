
ggplot_paper2 <- function(df, y_var, x_var, fill_var, shape_var=NULL, ylab_title, facet_var, tuk_letters=NULL, legend_is_condition = F ) {
  max_val <- max(df[,y_var]) + max(df[,y_var])*0.2
  ggplot(df, aes_string(y=y_var, x=x_var)) +
    geom_boxplot( aes_string( fill=fill_var #, shape=shape_var
    ) )+
    geom_point(aes_string(fill=fill_var #, shape=shape_var, size=3
    ),  
    position=position_jitterdodge(jitter.width=0.3,  dodge.width=0.7)) +
    scale_fill_manual(values=c("gold2", "seagreen")) +  
    scale_shape_manual(values=c(16, 4)) + 
    ylab(ylab_title) + 
    ylim(c(min(df[,y_var]), max_val)) +
    #  ylim(c(0, max_val)) +
    theme_gray(base_size = 14) +
    theme(axis.title.x=element_blank(),
          axis.text.x=element_blank(),
          axis.ticks.x=element_blank()) +
    if(!is.null(tuk_letters)) stat_summary(geom='text',  aes_string(y=y_var, x=x_var), label=tuk_letters, fun=max, vjust=-1) 
}

ggplot_paper2_layout <- function(df, y_var, x_var, fill_var, shape_var=NULL, size_var=NULL, ylab_title, facet_var, tuk_letters=NULL, legend_is_condition = F ) {
  max_val <- max(df[,y_var]) + max(df[,y_var])*0.2
  ggplot(df, aes_string(y=y_var, x=x_var)) +
    geom_boxplot( aes_string( fill=fill_var, shape=shape_var
    ), position=position_dodge2(0.9) )+
    geom_point( aes_string( fill=fill_var , shape=shape_var, size=size_var ),   position=position_jitterdodge(jitter.width=0.3,  # <<-adjusted
                                                                                                              dodge.width=0.7)) +
    scale_fill_manual(name = "Condition", labels = c("BX+ soil", "BX- soil"), values=c("gold2", "seagreen")) + 
    scale_shape_manual(values=c(16, 1)) + 
    scale_size_manual(values=c(2,2)) +
    ylab(ylab_title, size=10) + 
    ylim(c(min(df[,y_var]), max_val)) +
    #  ylim(c(0, max_val)) +
    theme_gray(base_size = 14) +
    theme(axis.title.x=element_blank(),
          axis.text.x=element_blank(),
          axis.ticks.x=element_blank())# +
  #if(!is.null(tuk_letters)) stat_summary(geom='text',  aes_string(y=y_var, x=x_var), label=tuk_letters, fun=max, vjust=-1) 
}

ggplot_paper2_layout_exp2 <- function(df, y_var, x_var, fill_var, shape_var=NULL, size_var=NULL, ylab_title, facet_var, tuk_letters=NULL, legend_is_condition = F ) {
  max_val <- max(df[,y_var]) + max(df[,y_var])*0.2
  ggplot(df, aes_string(y=y_var, x=x_var)) +
    geom_boxplot( aes_string( fill=fill_var, shape=shape_var
    ), position=position_dodge2(0.9) )+
    geom_point( aes_string( fill=fill_var , shape=shape_var, size=size_var),   position=position_jitterdodge(jitter.width=0.3,  # <<-adjusted
                                                                                                             dodge.width=0.7)) +
    scale_fill_manual(name = "Condition", labels = c("BX+ soil", "BX- soil"), values=c("gold2", "seagreen")) + 
    scale_shape_manual(values=c(16, 1)) + 
    scale_size_manual(values=c(2,2)) +
    ylab(ylab_title) + 
    ylim(c(min(df[,y_var]), max_val)) +
    #  ylim(c(0, max_val)) +
    theme_gray(base_size = 14) +
    theme(axis.title.x=element_blank())# +
  #if(!is.null(tuk_letters)) stat_summary(geom='text',  aes_string(y=y_var, x=x_var), label=tuk_letters, fun=max, vjust=-1) 
}


# ggplot_paper2_layout <- function(df, y_var, x_var, fill_var, shape_var, size_var, ylab_title, facet_var, tuk_letters=NULL, legend_is_condition = F ) {
#  max_val <- max(df[,y_var]) + max(df[,y_var])*0.2
#   ggplot(df, aes_string(y=y_var, x=x_var)) +
#   geom_boxplot( aes_string( fill=fill_var, shape=shape_var
#                             ), position=position_dodge2(0.9) )+
#   geom_point(aes_string( fill=fill_var , shape=shape_var, size=size_var
#                          ),  
#                          position=position_jitterdodge(jitter.width=0.3,  # <<- adjusted
#                                            dodge.width=0.7)) +
#   scale_fill_manual(values=c("gold2", "seagreen")) +  
#     scale_shape_manual(values=c(16, 1)) + 
#     scale_size_manual(values=c(2,2)) +
#   ylab(ylab_title) + 
#     ylim(c(min(df[,y_var]), max_val)) +
#    #  ylim(c(0, max_val)) +
#   theme_gray(base_size = 14) +
#     theme(axis.title.x=element_blank(),
#         axis.text.x=element_blank(),
#         axis.ticks.x=element_blank()) +
#    if(!is.null(tuk_letters)) stat_summary(geom='text',  aes_string(y=y_var, x=x_var), label=tuk_letters, fun=max, vjust=-1) 
# }

ggplot_paper2_bar_layout <- function(df, x_var, y_var, fill_var, shape_var=NULL, size_var=NULL, ylab_title, signif_y, signif) {
  max_val <- max(df[,y_var]) + max(df[,y_var])*0.2
  ggplot(df, aes_string(y=y_var, x=x_var)) +
    geom_bar(aes_string( fill=fill_var), stat="summary",fun="mean", position=position_dodge2(0.9) ) +
    geom_point(aes_string( fill=fill_var, shape=shape_var, size=size_var ),   position=position_jitterdodge(jitter.width=0.3, dodge.width=0.7)) +
    scale_fill_manual(values=c("gold2", "seagreen")) +  
    scale_shape_manual(values=c(16, 1)) + 
    scale_size_manual(values=c(2,2)) +
    ylab(ylab_title) + 
    ylim(c(min(df[,y_var]), max_val)) +
    ylim(c(0, max_val)) +
    theme_gray(base_size = 14) +
    theme(axis.title.x=element_blank(),
          # axis.text.x=element_blank(),
          axis.ticks.x=element_blank()) + facet_grid(~soil)  +
    labs(fill = "Soil condition", shape="Wheat cultivar", size="Wheat cultivar") +
    stat_summary(geom='text',  aes_string( x=x_var, y=signif_y), label=signif, size=8) # +
  #if(!is.null(tuk_letters)) stat_summary(geom='text',  aes_string(y=y_var, x=x_var), label=tuk_letters, fun=max, vjust=-1) 
}

# function for calculating effect size in aov
eta_calc <- function(aov_object) {round(aov_object[rownames(aov_object)[grep("BX_condition",rownames(aov_object))[1]]
                                                   ,]$`Sum Sq` *100 / aov_object[length(aov_object$`Sum Sq`),]$`Sum Sq`,2)
}





# 
# calc_values <- function(df, x, soil=F, line=F, line_soil=F) {
#   
#   if (soil==T){
#     mean_plus_Ch <- mean(df[df$BX_condition=="BX+"& df$soil=="Changins",x], na.rm=T)
#     sd_plus_Ch <- sd(df[df$BX_condition=="BX+"& df$soil=="Changins",x], na.rm=T)
#     mean_minus_Ch <- mean(df[df$BX_condition=="BX-"& df$soil=="Changins",x], na.rm=T)
#     sd_minus_Ch <- sd(df[df$BX_condition=="BX-"& df$soil=="Changins",x], na.rm=T)
#     mean_plus_Re <- mean(df[df$BX_condition=="BX+"& df$soil=="Reckenholz",x], na.rm=T)
#     sd_plus_Re <- sd(df[df$BX_condition=="BX+"& df$soil=="Reckenholz",x], na.rm=T)
#     mean_minus_Re <- mean(df[df$BX_condition=="BX-"& df$soil=="Reckenholz",x], na.rm=T) # replace by apply function
#     sd_minus_Re <- sd(df[df$BX_condition=="BX-"& df$soil=="Reckenholz",x], na.rm=T)
#     # % change of the mean (sdparate soils / wheat lines?)
#     percent_change_Ch <- (mean_minus_Ch - mean_plus_Ch)*100 / mean_minus_Ch
#     percent_change_Re <- (mean_minus_Re - mean_plus_Re)*100 / mean_minus_Re
#     min_Ch <- min(df[df$soil=="Changins",x], na.rm=T) 
#     max_Ch <- max(df[df$soil=="Changins",x], na.rm=T)
#     min_Re <- min(df[df$soil=="Reckenholz",x], na.rm=T) 
#     max_Re <- max(df[df$soil=="Reckenholz",x], na.rm=T)
#     
#   } else if (line==T) {
#     mean_plus_Dr <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter",x], na.rm=T)
#     sd_plus_Dr <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter",x], na.rm=T)
#     mean_minus_Dr <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter",x], na.rm=T)
#     sd_minus_Dr <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter",x], na.rm=T) 
#     mean_plus_Fio <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina",x], na.rm=T)
#     sd_plus_Fio <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina",x], na.rm=T)
#     mean_minus_Fio <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina",x], na.rm=T) 
#     sd_minus_Fio <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina",x], na.rm=T) # replace by apply function
#     # % change of the mean (separate soils / wheat lines?)
#     percent_change_Dr <- (mean_minus_Dr - mean_plus_Dr)*100 / mean_minus_Dr
#     percent_change_Fio <- (mean_minus_Fio - mean_plus_Fio)*100 / mean_minus_Fio
#   } 
#   
#   else if (line_soil==T) {
#     mean_plus_Dr_Ch <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter"& df$soil=="Changins",x], na.rm=T)
#     sd_plus_Dr_Ch <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter"& df$wheat_line=="Drifter"& df$soil=="Changins",x], na.rm=T)
#     mean_minus_Dr_Ch <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter"& df$wheat_line=="Drifter"& df$soil=="Changins",x], na.rm=T)
#     sd_minus_Dr_Ch <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter"& df$wheat_line=="Drifter"& df$soil=="Changins",x], na.rm=T) 
#     mean_plus_Fio_Ch <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina"& df$soil=="Changins",x], na.rm=T)
#     sd_plus_Fio_Ch <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina"& df$soil=="Changins",x], na.rm=T)
#     mean_minus_Fio_Ch <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina"& df$soil=="Changins",x], na.rm=T) 
#     sd_minus_Fio_Ch <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina"& df$soil=="Changins",x], na.rm=T) # replace by apply function
#     
#     mean_plus_Dr_Re <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter"& df$wheat_line=="Drifter"& df$soil=="Reckenholz",x], na.rm=T)
#     sd_plus_Dr_Re <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter"& df$soil=="Reckenholz",x], na.rm=T)
#     mean_minus_Dr_Re <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter"& df$soil=="Reckenholz",x], na.rm=T)
#     sd_minus_Dr_Re <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter"& df$soil=="Reckenholz",x], na.rm=T) 
#     mean_plus_Fio_Re <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina"& df$soil=="Reckenholz",x], na.rm=T)
#     sd_plus_Fio_Re <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina"& df$soil=="Reckenholz",x], na.rm=T)
#     mean_minus_Fio_Re <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina"& df$soil=="Reckenholz",x], na.rm=T) 
#     sd_minus_Fio_Re <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina"& df$soil=="Reckenholz",x], na.rm=T) # replace by apply function
#     
#     # % change of the mean (separate soils / wheat lines?)
#     percent_change_Dr_Ch <- (mean_minus_Dr_Ch - mean_plus_Dr_Ch)*100 / mean_minus_Dr_Ch
#     percent_change_Fio_Ch <- (mean_minus_Fio_Ch - mean_plus_Fio_Ch)*100 / mean_minus_Fio_Ch
#     percent_change_Dr_Re <- (mean_minus_Dr_Re - mean_plus_Dr_Re)*100 / mean_minus_Dr_Re
#     percent_change_Fio_Re <- (mean_minus_Fio_Re - mean_plus_Fio_Re)*100 / mean_minus_Fio_Re
#     min_Ch <- min(df[df$soil=="Changins",x], na.rm=T)
#     max_Ch <- max(df[df$soil=="Changins",x], na.rm=T)
#     min_Re <- min(df[df$soil=="Reckenholz",x], na.rm=T)
#     max_Re <- max(df[df$soil=="Reckenholz",x], na.rm=T)
#   } 
#   
#   else { 
#     mean_plus <- mean(df[df$BX_condition=="BX+",x], na.rm=T)
#     sd_plus <- sd(df[df$BX_condition=="BX+",x], na.rm=T)
#     mean_minus <- mean(df[df$BX_condition=="BX-",x], na.rm=T) 
#     sd_minus <- sd(df[df$BX_condition=="BX-",x], na.rm=T) 
#     percent_change <- (mean_minus - mean_plus)*100 / mean_minus
#     min <- min(df[,x], na.rm=T)
#     max <- max(df[,x], na.rm=T)
#   }
#   
#   if (soil==T) { 
#     values <- c(mean_plus_Ch, sd_plus_Ch, mean_minus_Ch, sd_minus_Ch,
#                 mean_plus_Re, sd_plus_Re, mean_minus_Re, sd_minus_Re,
#                 round(percent_change_Ch,2), round(percent_change_Re,2),
#                 round(min_Ch,2), round(max_Ch,2),  round(min_Re,2), round(max_Re,2))
#   } else if (line==T) {
#     values <- c(mean_plus_Dr, sd_plus_Dr, mean_minus_Dr, sd_minus_Dr,
#                 mean_plus_Fio, sd_plus_Fio, mean_minus_Fio, sd_minus_Fio,
#                 round(percent_change_Dr,2), round(percent_change_Fio,2)) # replace by apply function
#   } else if (line_soil==T) {
#     values <- c(mean_plus_Dr_Ch, sd_plus_Dr_Ch, mean_minus_Dr_Ch, sd_minus_Dr_Ch,
#                 mean_plus_Fio_Ch, sd_plus_Fio_Ch, mean_minus_Fio_Ch, sd_minus_Fio_Ch,
#                 round(percent_change_Dr_Ch,2), round(percent_change_Fio_Ch,2), 
#                 round(min_Ch,2), round(max_Ch,2),
#                 mean_plus_Dr_Re, sd_plus_Dr_Re, mean_minus_Dr_Re, sd_minus_Dr_Re,
#                 mean_plus_Fio_Re, sd_plus_Fio_Re, mean_minus_Fio_Re, sd_minus_Fio_Re,
#                 round(percent_change_Dr_Re,2), round(percent_change_Fio_Re,2), 
#                 round(min_Re,2), round(max_Re,2)) # replace by apply function
#   } else { 
#     values <- c(round(mean_plus,2), round(sd_plus,2),round(mean_minus,2),
#                 round(sd_minus,2), round(percent_change,2), min, max)
#   }
# }
# 


calc_values <- function(df, x, soil=F, line=F, line_soil=F) {
  
  if (soil==T){
    mean_plus_Ch15 <- mean(df[df$BX_condition=="BX+"& df$soil_year=="Changins 2015",x], na.rm=T)
    sd_plus_Ch15 <- sd(df[df$BX_condition=="BX+"& df$soil_year=="Changins 2015",x], na.rm=T)
    mean_minus_Ch15 <- mean(df[df$BX_condition=="BX-"& df$soil_year=="Changins 2015",x], na.rm=T)
    sd_minus_Ch15 <- sd(df[df$BX_condition=="BX-"& df$soil_year=="Changins 2015",x], na.rm=T)
    percent_change_Ch15 <- (mean_minus_Ch15 - mean_plus_Ch15)*100 / mean_minus_Ch15
    
    mean_plus_Re16 <- mean(df[df$BX_condition=="BX+"& df$soil_year=="Reckenholz 2016",x], na.rm=T)
    sd_plus_Re16 <- sd(df[df$BX_condition=="BX+"& df$soil_year=="Reckenholz 2016",x], na.rm=T)
    mean_minus_Re16 <- mean(df[df$BX_condition=="BX-"& df$soil_year=="Reckenholz 2016",x], na.rm=T)
    sd_minus_Re16 <- sd(df[df$BX_condition=="BX-"& df$soil_year=="Reckenholz 2016",x], na.rm=T)
    #percent_change_Re16 <- (mean_minus_Re16 - mean_plus_Re16)*100 / mean_minus_Re16
    percent_diff_Re16 <- (mean_minus_Re16 - mean_plus_Re16)*100 / 
      ((mean_minus_Re16 + mean_plus_Re16)/2)
    
    mean_plus_Re15 <- mean(df[df$BX_condition=="BX+"& df$soil_year=="Reckenholz 2015",x], na.rm=T)
    sd_plus_Re15 <- sd(df[df$BX_condition=="BX+"& df$soil_year=="Reckenholz 2015",x], na.rm=T)
    mean_minus_Re15 <- mean(df[df$BX_condition=="BX-"& df$soil_year=="Reckenholz 2015",x], na.rm=T)
    sd_minus_Re15 <- sd(df[df$BX_condition=="BX-"& df$soil_year=="Reckenholz 2015",x], na.rm=T)
  #percent_change_Re15 <- (mean_minus_Re15 - mean_plus_Re15)*100 / mean_minus_Re15
    percent_diff_Re15 <- (mean_minus_Re15 - mean_plus_Re15)*100 /  ((mean_minus_Re15 + mean_plus_Re15)/2)
    
    
  } else if (line==T) {
    mean_plus_Dr <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter",x], na.rm=T)
    sd_plus_Dr <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter",x], na.rm=T)
    mean_minus_Dr <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter",x], na.rm=T)
    sd_minus_Dr <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter",x], na.rm=T) 
    mean_plus_Fio <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina",x], na.rm=T)
    sd_plus_Fio <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina",x], na.rm=T)
    mean_minus_Fio <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina",x], na.rm=T) 
    sd_minus_Fio <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina",x], na.rm=T) # replace by apply function
    # % change of the mean (separate soils / wheat lines?)
    #percent_change_Dr <- (mean_minus_Dr - mean_plus_Dr)*100 / mean_minus_Dr
    #percent_change_Fio <- (mean_minus_Fio - mean_plus_Fio)*100 / mean_minus_Fio
    percent_change_Dr <- (mean_minus_Dr - mean_plus_Dr)*100 / ((mean_minus_Dr + mean_plus_Dr)/2)
    percent_change_Fio <- (mean_minus_Fio - mean_plus_Fio)*100 / ((mean_minus_Fio + mean_plus_Fio)/2)
  } 
  
  else if (line_soil==T) {
    mean_plus_Dr_Ch <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter"& df$soil=="Changins",x], na.rm=T)
    sd_plus_Dr_Ch <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter"& df$wheat_line=="Drifter"& df$soil=="Changins",x], na.rm=T)
    mean_minus_Dr_Ch <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter"& df$wheat_line=="Drifter"& df$soil=="Changins",x], na.rm=T)
    sd_minus_Dr_Ch <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter"& df$wheat_line=="Drifter"& df$soil=="Changins",x], na.rm=T) 
    mean_plus_Fio_Ch <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina"& df$soil=="Changins",x], na.rm=T)
    sd_plus_Fio_Ch <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina"& df$soil=="Changins",x], na.rm=T)
    mean_minus_Fio_Ch <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina"& df$soil=="Changins",x], na.rm=T) 
    sd_minus_Fio_Ch <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina"& df$soil=="Changins",x], na.rm=T) # replace by apply function
    
    mean_plus_Dr_Re <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter"& df$wheat_line=="Drifter"& df$soil=="Reckenholz",x], na.rm=T)
    sd_plus_Dr_Re <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Drifter"& df$soil=="Reckenholz",x], na.rm=T)
    mean_minus_Dr_Re <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter"& df$soil=="Reckenholz",x], na.rm=T)
    sd_minus_Dr_Re <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Drifter"& df$soil=="Reckenholz",x], na.rm=T) 
    mean_plus_Fio_Re <- mean(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina"& df$soil=="Reckenholz",x], na.rm=T)
    sd_plus_Fio_Re <- sd(df[df$BX_condition=="BX+"& df$wheat_line=="Fiorina"& df$soil=="Reckenholz",x], na.rm=T)
    mean_minus_Fio_Re <- mean(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina"& df$soil=="Reckenholz",x], na.rm=T) 
    sd_minus_Fio_Re <- sd(df[df$BX_condition=="BX-"& df$wheat_line=="Fiorina"& df$soil=="Reckenholz",x], na.rm=T) # replace by apply function
    
    # % change of the mean (separate soils / wheat lines?)
    percent_change_Dr_Ch <- (mean_minus_Dr_Ch - mean_plus_Dr_Ch)*100 / mean_minus_Dr_Ch
    percent_change_Fio_Ch <- (mean_minus_Fio_Ch - mean_plus_Fio_Ch)*100 / mean_minus_Fio_Ch
    percent_change_Dr_Re <- (mean_minus_Dr_Re - mean_plus_Dr_Re)*100 / mean_minus_Dr_Re
    percent_change_Fio_Re <- (mean_minus_Fio_Re - mean_plus_Fio_Re)*100 / mean_minus_Fio_Re
  } 
  
  else { 
    mean_plus <- mean(df[df$BX_condition=="BX+",x], na.rm=T)
    sd_plus <- sd(df[df$BX_condition=="BX+",x], na.rm=T)
    mean_minus <- mean(df[df$BX_condition=="BX-",x], na.rm=T) 
    sd_minus <- sd(df[df$BX_condition=="BX-",x], na.rm=T) 
    #percent_change <- (mean_minus - mean_plus)*100 / mean_minus
  }
  
  if (soil==T) { 
    values <- c(mean_plus_Ch15, sd_plus_Ch15, mean_plus_Ch15, sd_minus_Ch15, 
                round(percent_change_Ch15,2),
                mean_plus_Re16, sd_plus_Re16, mean_plus_Re16, sd_minus_Re16,
                round(percent_change_Re16,2),  round(percent_change_Re16_2,2), 
                mean_plus_Re15, sd_plus_Re15, mean_plus_Re15, sd_plus_Re15,
               round(percent_change_Re15,2))
  } else if (line==T) {
    values <- c(mean_plus_Dr, sd_plus_Dr, mean_minus_Dr, sd_minus_Dr,
                mean_plus_Fio, sd_plus_Fio, mean_minus_Fio, sd_minus_Fio,
                round(percent_change_Dr,2), round(percent_change_Fio,2)) 
  } else if (line_soil==T) {
    values <- c(mean_plus_Dr_Ch, sd_plus_Dr_Ch, mean_minus_Dr_Ch, sd_minus_Dr_Ch,
                mean_plus_Fio_Ch, sd_plus_Fio_Ch, mean_minus_Fio_Ch, sd_minus_Fio_Ch,
                round(percent_change_Dr_Ch,2), round(percent_change_Fio_Ch,2), 
                mean_plus_Dr_Re, sd_plus_Dr_Re, mean_minus_Dr_Re, sd_minus_Dr_Re,
                mean_plus_Fio_Re, sd_plus_Fio_Re, mean_minus_Fio_Re, sd_minus_Fio_Re,
                round(percent_change_Dr_Re,2), round(percent_change_Fio_Re,2))
  } else { 
    values <- c(round(mean_plus,2), round(sd_plus,2),round(mean_minus,2),
                round(sd_minus,2), round(percent_change,2))
  }
}


